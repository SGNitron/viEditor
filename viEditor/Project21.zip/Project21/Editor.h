//Editor.h
#pragma once
#include "LinkedList.h"
#include "BinarySearchTree.h"
#include "Point.h"
#include "ArrayStack.h"
#include "Snapshot.h"
#include <string>
using namespace std;
class Editor
{
public:
	Editor();
	void readfile(const string, const string);
	void run();
	void display()const;
private:
	LinkedList<string> lines;
	Point Position;
	ArrayStack<Snapshot> undoStack;
	int CurSize(int);    //return the size of an entry within the linkedlist
	BinarySearchTree<string>* keywords;
};